import { motion } from 'motion/react';
import { CheckCircle2, ArrowUpRight } from 'lucide-react';

const projects = [
  {
    id: 1,
    title: "Aura Skincare",
    category: "Identidade de Marca",
    description: "Identidade visual completa e design de embalagem para uma linha de cuidados com a pele premium e orgânica.",
    objective: "Posicionar a marca no segmento de mercado de luxo ecológico.",
    image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?q=80&w=1974&auto=format&fit=crop",
    color: "from-rose-500/20 to-orange-500/20"
  },
  {
    id: 2,
    title: "Fintech App UI",
    category: "Design Digital",
    description: "Visuais de marketing e sistema de mídias sociais para um aplicativo bancário moderno.",
    objective: "Aumentar a confiança do usuário e impulsionar downloads do aplicativo através de um design limpo e acessível.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop",
    color: "from-blue-500/20 to-cyan-500/20"
  },
  {
    id: 3,
    title: "Nexus Tech",
    category: "Direção de Arte",
    description: "Campanha de rebranding incluindo redesign de logotipo, sistema tipográfico e diretrizes de marca.",
    objective: "Modernizar uma empresa de tecnologia B2B tradicional para atrair startups corporativas.",
    image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1964&auto=format&fit=crop",
    color: "from-purple-500/20 to-indigo-500/20"
  },
  {
    id: 4,
    title: "Oasis Coffee",
    category: "Mídias Sociais",
    description: "Uma estratégia coesa de grid para Instagram e sistema de templates para uma torrefação de café boutique.",
    objective: "Aumentar o engajamento e criar uma estética reconhecível em todos os pontos de contato sociais.",
    image: "https://images.unsplash.com/photo-1497935586351-b67a49e012bf?q=80&w=1975&auto=format&fit=crop",
    color: "from-amber-500/20 to-yellow-500/20"
  }
];

export default function Portfolio() {
  return (
    <section id="portfolio" className="py-24 relative bg-black overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-3xl h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-gradient-to-b from-purple-500/10 via-transparent to-transparent blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-6">
            Projetos <span className="text-gradient-color">Selecionados</span>
          </h2>
          <p className="text-white/50 max-w-2xl mx-auto text-lg">
            Uma vitrine de soluções visuais estratégicas projetadas para elevar marcas e gerar resultados.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {projects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group relative rounded-3xl bg-zinc-900/50 border border-white/5 overflow-hidden hover:border-white/20 transition-colors duration-500"
            >
              {/* Hover Gradient Background */}
              <div className={`absolute inset-0 bg-gradient-to-br ${project.color} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
              
              <div className="relative p-8 flex flex-col h-full">
                <div className="flex justify-between items-start mb-8">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-white/70">
                    <span className="w-2 h-2 rounded-full bg-white/50" />
                    {project.category}
                  </div>
                  <button className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/50 group-hover:text-white group-hover:bg-white/10 transition-all">
                    <ArrowUpRight size={18} />
                  </button>
                </div>

                <div className="mb-8 rounded-2xl overflow-hidden aspect-[16/9] relative">
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors duration-500 z-10" />
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <h3 className="text-2xl font-display font-bold text-white mb-3 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-white/70 transition-all">
                  {project.title}
                </h3>
                <p className="text-white/60 mb-6 flex-grow">
                  {project.description}
                </p>

                <div className="pt-6 border-t border-white/10">
                  <div className="flex items-start gap-3">
                    <CheckCircle2 size={20} className="text-blue-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="block text-sm font-medium text-white/80 mb-1">Objetivo</span>
                      <span className="block text-sm text-white/50">{project.objective}</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
