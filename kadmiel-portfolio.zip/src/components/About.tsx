import { motion } from 'motion/react';

export default function About() {
  return (
    <section id="about" className="py-24 relative z-10 bg-black">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl md:text-5xl font-display font-bold tracking-tight mb-6">
              Projetando para <span className="text-gradient-color">impacto</span> e <span className="text-gradient-color">crescimento</span>.
            </h2>
            <p className="text-lg text-white/60 mb-6 leading-relaxed">
              Com mais de 3 anos de experiência em design gráfico, sou especialista em criar identidades visuais que fazem mais do que apenas parecerem boas — elas comunicam a mensagem central da sua marca e geram resultados reais de negócios.
            </p>
            <p className="text-lg text-white/60 leading-relaxed">
              Minha abordagem é baseada em estratégia. Antes de abrir qualquer software de design, trabalho para entender seus objetivos, seu público e seu mercado. O resultado é uma presença visual coesa e premium que destaca você.
            </p>
            
            <div className="mt-10 grid grid-cols-2 gap-8">
              <div>
                <div className="text-4xl font-display font-bold text-white mb-2">3+</div>
                <div className="text-sm text-white/50 font-medium uppercase tracking-wider">Anos de Experiência</div>
              </div>
              <div>
                <div className="text-4xl font-display font-bold text-white mb-2">50+</div>
                <div className="text-sm text-white/50 font-medium uppercase tracking-wider">Projetos Entregues</div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-square rounded-3xl overflow-hidden border border-white/10 relative group">
              <div className="absolute inset-0 bg-gradient-to-tr from-blue-500/20 to-orange-500/20 mix-blend-overlay z-10 group-hover:opacity-0 transition-opacity duration-500" />
              <img 
                src="https://images.unsplash.com/photo-1600697395543-ef3ee6e9af7b?q=80&w=2070&auto=format&fit=crop" 
                alt="Designer Workspace" 
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 scale-105 group-hover:scale-100"
                referrerPolicy="no-referrer"
              />
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -top-6 -right-6 w-24 h-24 bg-purple-500/30 blur-2xl rounded-full" />
            <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-blue-500/20 blur-3xl rounded-full" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
