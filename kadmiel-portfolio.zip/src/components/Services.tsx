import { motion } from 'motion/react';
import { CheckCircle2, XCircle } from 'lucide-react';

const services = [
  "Design de Identidade de Marca",
  "Design para Mídias Sociais",
  "Visuais de Marketing",
  "Direção de Arte",
  "Design de Embalagens",
  "Visuais de UI/UX"
];

const painPoints = [
  "Presença visual inconsistente em diferentes plataformas",
  "Design que parece bom, mas não converte",
  "Dificuldade para se destacar em um mercado saturado",
  "Falta de diretrizes de marca claras para sua equipe"
];

export default function Services() {
  return (
    <section id="services" className="py-32 bg-white text-black relative overflow-hidden">
      {/* Top gradient transition */}
      <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-black to-transparent z-10" />
      
      {/* Abstract glowing orb background */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] opacity-20 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-400 via-purple-400 to-orange-400 rounded-full blur-[100px] animate-pulse" style={{ animationDuration: '6s' }} />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-20">
        <div className="text-center mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-100 text-purple-700 text-sm font-semibold mb-6">
            <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
            Serviços
          </div>
          <h2 className="text-4xl md:text-6xl font-display font-bold mb-6 tracking-tight">
            Pare de se misturar.<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-purple-600 to-orange-500">
              Comece a se destacar.
            </span>
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-center">
          {/* Left Column - Pain Points */}
          <div className="space-y-4">
            {painPoints.map((point, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white/80 backdrop-blur-sm border border-black/5 p-6 rounded-2xl shadow-sm hover:shadow-md transition-shadow"
              >
                <XCircle size={20} className="text-zinc-400 mb-3" />
                <p className="text-zinc-600 font-medium">{point}</p>
              </motion.div>
            ))}
          </div>

          {/* Center Graphic */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative aspect-square flex items-center justify-center"
          >
            {/* Concentric circles */}
            <div className="absolute inset-4 border border-purple-200 rounded-full animate-[spin_20s_linear_infinite]" />
            <div className="absolute inset-12 border border-blue-200 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
            <div className="absolute inset-20 border border-orange-200 rounded-full animate-[spin_10s_linear_infinite]" />
            
            {/* Center core */}
            <div className="w-32 h-32 bg-gradient-to-tr from-blue-500 to-purple-500 rounded-full blur-md" />
            <div className="absolute w-32 h-32 bg-white rounded-full flex items-center justify-center shadow-xl">
              <span className="font-display font-bold text-xl tracking-tighter">Estratégia</span>
            </div>
          </motion.div>

          {/* Right Column - Solutions/Services */}
          <div className="space-y-4">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white/80 backdrop-blur-sm border border-black/5 p-6 rounded-2xl shadow-sm hover:shadow-md transition-shadow"
              >
                <CheckCircle2 size={20} className="text-blue-600 mb-3" />
                <p className="text-black font-semibold">{service}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
