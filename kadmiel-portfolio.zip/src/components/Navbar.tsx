import { motion } from 'motion/react';
import { Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 flex justify-center p-4 pointer-events-none">
      <div className="w-full max-w-5xl bg-white/5 border border-white/10 backdrop-blur-md rounded-full px-6 py-3 flex items-center justify-between pointer-events-auto">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-blue-500 to-orange-500" />
          <span className="font-display font-bold text-lg tracking-tight">Kadmiel</span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-white/70">
          <a href="#about" className="hover:text-white transition-colors">Sobre</a>
          <a href="#portfolio" className="hover:text-white transition-colors">Portfólio</a>
          <a href="#services" className="hover:text-white transition-colors">Serviços</a>
        </div>

        <div className="hidden md:flex">
          <a href="#contact" className="bg-white text-black px-5 py-2 rounded-full text-sm font-semibold hover:bg-white/90 transition-colors">
            Trabalhe Comigo
          </a>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-white" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-20 left-4 right-4 bg-zinc-900 border border-white/10 rounded-2xl p-4 flex flex-col gap-4 pointer-events-auto md:hidden"
        >
          <a href="#about" onClick={() => setIsOpen(false)} className="text-white/70 hover:text-white p-2">Sobre</a>
          <a href="#portfolio" onClick={() => setIsOpen(false)} className="text-white/70 hover:text-white p-2">Portfólio</a>
          <a href="#services" onClick={() => setIsOpen(false)} className="text-white/70 hover:text-white p-2">Serviços</a>
          <a href="#contact" onClick={() => setIsOpen(false)} className="bg-white text-black px-5 py-3 rounded-xl text-sm font-semibold text-center mt-2">
            Trabalhe Comigo
          </a>
        </motion.div>
      )}
    </nav>
  );
}
