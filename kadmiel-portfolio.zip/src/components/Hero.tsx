import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Animated Background Grid */}
      <div className="absolute inset-0 bg-grid-white/[0.03] bg-[size:40px_40px]" />
      
      {/* Glowing Center */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[600px] opacity-30 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-orange-500 blur-[100px] rounded-full mix-blend-screen animate-pulse" style={{ animationDuration: '4s' }} />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="mb-8"
        >
          {/* Abstract Triangle Graphic */}
          <div className="relative w-48 h-48 mx-auto mb-12">
            <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-2xl">
              <defs>
                <linearGradient id="grad" x1="0%" y1="100%" x2="50%" y2="0%">
                  <stop offset="0%" stopColor="#fff" stopOpacity="0.1" />
                  <stop offset="100%" stopColor="#fff" stopOpacity="1" />
                </linearGradient>
              </defs>
              <polygon points="50,10 90,90 10,90" fill="url(#grad)" />
              {/* Inner lines for tech feel */}
              <polygon points="50,20 80,85 20,85" fill="none" stroke="rgba(0,0,0,0.5)" strokeWidth="0.5" />
              <polygon points="50,30 70,80 30,80" fill="none" stroke="rgba(0,0,0,0.5)" strokeWidth="0.5" />
              <polygon points="50,40 60,75 40,75" fill="none" stroke="rgba(0,0,0,0.5)" strokeWidth="0.5" />
            </svg>
          </div>

          <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-bold tracking-tighter mb-6">
            <span className="text-gradient">Construa design</span><br />
            <span className="text-gradient">estratégico.</span>
          </h1>
          
          <p className="text-lg md:text-xl text-white/50 max-w-2xl mx-auto mb-10 font-light">
            Sou Kadmiel, um designer gráfico ajudando marcas a crescerem através de soluções visuais intencionais de alto padrão e direção de arte.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="#portfolio" className="group relative inline-flex items-center justify-center gap-2 bg-white text-black px-8 py-4 rounded-full font-semibold text-sm transition-transform hover:scale-105">
              Ver Projetos
              <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a href="#contact" className="inline-flex items-center justify-center px-8 py-4 rounded-full font-semibold text-sm text-white bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
              Trabalhe Comigo
            </a>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 1 }}
          className="mt-24 flex items-center gap-4 text-sm text-white/40 font-mono"
        >
          <span>Desenvolva com intenção &gt;_</span>
          <span>Lance globalmente &#127758;</span>
          <span>Continue evoluindo &uarr;</span>
        </motion.div>
      </div>
      
      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent" />
    </section>
  );
}
