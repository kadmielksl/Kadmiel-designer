export default function Footer() {
  return (
    <footer className="bg-black border-t border-white/10 py-12">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-blue-500 to-orange-500" />
          <span className="font-display font-bold text-lg tracking-tight text-white">Kadmiel</span>
        </div>
        
        <div className="flex items-center gap-6 text-sm font-medium text-white/50">
          <a href="#" className="hover:text-white transition-colors">Behance</a>
          <a href="#" className="hover:text-white transition-colors">LinkedIn</a>
          <a href="#" className="hover:text-white transition-colors">Instagram</a>
        </div>

        <div className="text-sm text-white/30">
          &copy; {new Date().getFullYear()} Kadmiel Design. Todos os direitos reservados.
        </div>
      </div>
    </footer>
  );
}
